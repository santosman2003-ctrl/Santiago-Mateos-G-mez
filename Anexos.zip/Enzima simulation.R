# Modelo enzima-nutriente estocástico (Gillespie)
# Adaptado a la notación del TFG (Allen, 2010)

modelo_enzima_nutriente <- function(c1, c2, c3, E0, N0, B0, P0, T_max, max_iter = 10000) {
  # Variables iniciales
  t <- 0
  E <- E0      # enzima libre
  N <- N0      # nutriente (antes S)
  B <- B0      # complejo enzima-nutriente (antes C)
  P <- P0      # producto
  
  # Registro histórico
  historia <- data.frame(tiempo = t, E = E, N = N, B = B, P = P)
  iter <- 0
  
  while (t < T_max && iter < max_iter) {
    # Tasas de reacción
    a1 <- c1 * E * N       # E + N → B
    a2 <- c2 * B           # B → E + N
    a3 <- c3 * B           # B → E + P
    a0 <- a1 + a2 + a3
    
    if (a0 <= 0) break
    
    # Tiempo hasta el siguiente evento
    t <- t + rexp(1, rate = a0)
    r <- runif(1)
    
    # Determinación del evento
    if (r < a1 / a0) {
      E <- E - 1
      N <- N - 1
      B <- B + 1
    } else if (r < (a1 + a2) / a0) {
      E <- E + 1
      N <- N + 1
      B <- B - 1
    } else {
      E <- E + 1
      P <- P + 1
      B <- B - 1
    }
    
    historia <- rbind(historia, data.frame(tiempo = t, E = E, N = N, B = B, P = P))
    iter <- iter + 1
  }
  
  return(historia)
}

# Ejemplo de simulación
set.seed(123)
simulacion <- modelo_enzima_nutriente(
  c1 = 0.001,  # formación de complejo
  c2 = 0.1,    # disociación
  c3 = 0.1,    # formación de producto
  E0 = 50, N0 = 10, B0 = 0, P0 = 0,
  T_max = 100
)

# Gráfico de resultados
matplot(simulacion$tiempo, simulacion[,2:5], type = "s", lty = 1, lwd = 2,
        col = c("blue", "orange", "red", "darkgreen"),
        xlab = "Tiempo", ylab = "Número de moléculas",
        main = "Modelo enzima-nutriente estocástico c1=0.01, c2=0.1 y c3=0.1")
legend("top", legend = c("Enzima libre (E)", "Nutriente (N)", "Complejo (B)", "Producto (P)"),
       col = c("blue", "orange", "red", "darkgreen"), lty = 1, lwd = 2)

