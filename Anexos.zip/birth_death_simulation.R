
# Proceso de nacimiento y muerte (Algoritmo de Gillespie)
# Basado en: Allen, L. J. S. (2010). An Introduction to Stochastic Processes with Applications to Biology (2nd ed.)

birth_death <- function(b, d, X0, T_max, max_iter = 10000) {
  times <- c(0)
  pops <- c(X0)
  t <- 0
  X <- X0
  iter <- 0
  
  while (t < T_max && X > 0 && iter < max_iter) {
    a1 <- b * X
    a2 <- d * X
    a0 <- a1 + a2
    
    if (a0 == 0) break  # si no hay más eventos posibles
    
    t <- t + rexp(1, rate = a0)
    if (runif(1) < a1 / a0) {
      X <- X + 1
    } else {
      X <- X - 1
    }
    
    times <- c(times, t)
    pops <- c(pops, X)
    iter <- iter + 1
  }
  
  return(data.frame(t = times, X = pops))
}


# Ejemplo de simulación
set.seed(1)
sim <- birth_death(b = 0.4, d = 0.8, X0 = 100, T_max = 50)

 # Gráfico del proceso
plot(sim$t, sim$X, type = "s", xlab = "Tiempo", ylab = "Población",
     main = "Proceso de Nacimiento y Muerte ",
     col = "blue", lwd = 2)

