# Modelo SIRS estocástico (Algoritmo de Gillespie)
# Basado en: Allen, L. J. S. (2010)

sirs_simulation <- function(beta, gamma, delta, S0, I0, R0, T_max, max_iter = 10000) {
  t <- 0
  S <- S0; I <- I0; R <- R0
  times <- c(t)
  history <- data.frame(time = t, S = S, I = I, R = R)
  iter <- 0
  
  while (t < T_max && (I > 0 || R > 0) && iter < max_iter) {
    # Tasas de transición
    a1 <- beta * S * I        # infección
    a2 <- gamma * I           # recuperación
    a3 <- delta * R           # pérdida de inmunidad
    a0 <- a1 + a2 + a3
    
    if (a0 <= 0) break
    
    # Tiempo hasta el siguiente evento
    t <- t + rexp(1, rate = a0)
    r <- runif(1)
    
    # Determinación del tipo de evento
    if (r < a1 / a0) {
      S <- S - 1; I <- I + 1  # infección
    } else if (r < (a1 + a2) / a0) {
      I <- I - 1; R <- R + 1  # recuperación
    } else {
      R <- R - 1; S <- S + 1  # pérdida de inmunidad
    }
    
    times <- c(times, t)
    history <- rbind(history, data.frame(time = t, S = S, I = I, R = R))
    iter <- iter + 1
  }
  
  return(history)
}

# Ejemplo de simulación
set.seed(123)
sim <- sirs_simulation(beta = 0.002, gamma = 0.7, delta = 0.05, S0 = 990, I0 = 10, R0 = 0, T_max = 100)

# Gráfico de resultados
matplot(sim$time, sim[,2:4], type = "s", col = c("blue", "red", "green"),
        xlab = "Tiempo", ylab = "Población", main = "Modelo SIRS Estocástico β=0.002, γ=0.4 y δ=0.5 ",
        lty = 1, lwd = 2)
legend("topright", legend = c("Susceptibles", "Infectados", "Recuperados"),
       col = c("blue", "red", "green"), lty = 1, lwd = 2)

