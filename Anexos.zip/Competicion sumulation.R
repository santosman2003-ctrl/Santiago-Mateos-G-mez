# Modelo estocástico de competencia entre especies (Gillespie)

competencia_simulacion <- function(a10, a11, a12, a20, a21, a22, 
                                   X1_0, X2_0, T_max, seed = 123, max_iter = 10000) {
  set.seed(seed)
  
  t <- 0
  X1 <- X1_0
  X2 <- X2_0
  tiempos <- c(t)
  X1_hist <- c(X1)
  X2_hist <- c(X2)
  iter <- 0
  
  while (t < T_max && X1 >= 0 && X2 >= 0 && iter < max_iter) {
    # Tasas de transición
    tasa_nac_1 <- a10 * X1
    tasa_mue_1 <- X1 * (a11 * X1 + a12 * X2)
    tasa_nac_2 <- a20 * X2
    tasa_mue_2 <- X2 * (a21 * X1 + a22 * X2)
    
    tasas <- c(tasa_nac_1, tasa_mue_1, tasa_nac_2, tasa_mue_2)
    a0 <- sum(tasas)
    if (a0 <= 0) break
    
    # Tiempo hasta el siguiente evento
    t <- t + rexp(1, rate = a0)
    evento <- sample(1:4, 1, prob = tasas / a0)
    
    # Actualización del estado
    if (evento == 1) X1 <- X1 + 1
    else if (evento == 2 && X1 > 0) X1 <- X1 - 1
    else if (evento == 3) X2 <- X2 + 1
    else if (evento == 4 && X2 > 0) X2 <- X2 - 1
    
    # Registro
    tiempos <- c(tiempos, t)
    X1_hist <- c(X1_hist, X1)
    X2_hist <- c(X2_hist, X2)
    iter <- iter + 1
  }
  
  return(data.frame(tiempo = tiempos, especie1 = X1_hist, especie2 = X2_hist))
}

# Ejemplo de simulación: Escenario 1 – Coexistencia estable
set.seed(123)
sim1 <- competencia_simulacion(
  a10 = 1.0,
  a11 = 0.01,
  a12 = 0.015,
  a20 = 1.0,
  a21 = 0.015,
  a22 = 0.01,
  # Condiciones iniciales cambiables:
  X1_0 = 60,
  X2_0 = 40,# => Gana especie 1
  # O:
  # X1_0 = 40
  # X2_0 = 60   => Gana especie 2
  
  
  
  
  T_max = 120,
  seed = 123

)

# Gráfico del resultado
matplot(sim1$tiempo, sim1[,2:3], type = "s", col = c("blue", "red"),
        lty = 1, lwd = 2, xlab = "Tiempo", ylab = "Tamaño poblacional",
        main = "Competencia entre especies – Extinción por condiciones iniciales")
legend("topright", legend = c("Especie 1", "Especie 2"),
       col = c("blue", "red"), lty = 1, lwd = 2)

