
# Modelos SI y SIS estocásticos con el algoritmo de Gillespie
# Basado en: Allen, L. J. S. (2010). An Introduction to Stochastic Processes with Applications to Biology (2nd ed.)

# Modelo SI (sin recuperación)
si_simulation <- function(beta, S0, I0, T_max, max_iter = 10000) {
  times <- c(0)
  S <- S0
  I <- I0
  t <- 0
  iter <- 0
  states <- data.frame(time = 0, S = S, I = I)

  while (t < T_max && S > 0 && iter < max_iter) {
    a1 <- beta * S * I
    if (a1 <= 0) break

    t <- t + rexp(1, rate = a1)
    S <- S - 1
    I <- I + 1

    states <- rbind(states, data.frame(time = t, S = S, I = I))
    iter <- iter + 1
  }
  return(states)
}

# Modelo SIS (con recuperación sin inmunidad)
sis_simulation <- function(beta, gamma, S0, I0, T_max, max_iter = 10000) {
  times <- c(0)
  S <- S0
  I <- I0
  t <- 0
  iter <- 0
  states <- data.frame(time = 0, S = S, I = I)

  while (t < T_max && I > 0 && iter < max_iter) {
    a1 <- beta * S * I
    a2 <- gamma * I
    a0 <- a1 + a2
    if (a0 <= 0) break

    t <- t + rexp(1, rate = a0)

    if (runif(1) < a1 / a0) {
      S <- S - 1
      I <- I + 1
    } else {
      S <- S + 1
      I <- I - 1
    }

    states <- rbind(states, data.frame(time = t, S = S, I = I))
    iter <- iter + 1
  }
  return(states)
}

# Ejemplo de simulación SI
set.seed(123)
sim_si <- si_simulation(beta = 0.0001, S0 = 999, I0 = 1, T_max = 100)
matplot(sim_si$time, sim_si[,2:3], type = "s", col = c("blue", "red"),
        xlab = "Tiempo", ylab = "Población", main = "Modelo SI Estocástico  β=0.0001, I0=1",
        lty = 1, lwd = 2)
legend("right", legend = c("Susceptibles", "Infectados"), col = c("blue", "red"), lty = 1, lwd = 2)

# Ejemplo de simulación SIS
set.seed(1182)
sim_sis <- sis_simulation(beta = 0.001, gamma = 0.5, S0 = 1000, I0 = 10, T_max = 100)

matplot(sim_sis$time, sim_sis[,2:3], type = "s", col = c("blue", "red"),
        xlab = "Tiempo", ylab = "Población", main = "Modelo SIS Estocástico β=0.0001, Y=0.8",
        lty = 1, lwd = 2)
legend("topright", legend = c("Susceptibles", "Infectados"), col = c("blue", "red"), lty = 1, lwd = 2)

