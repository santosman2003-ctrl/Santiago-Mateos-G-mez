# Modelo logístico estocástico (notación estándar: lambda, mu, K)
# Basado en: Allen, L. J. S. (2010)

logistic_growth_lambda_mu <- function(lambda, mu, K, X0, T_max, max_iter = 10000) {
  times <- c(0)
  pops <- c(X0)
  t <- 0
  X <- X0
  iter <- 0
  
  while (t < T_max && X > 0 && iter < max_iter) {
    # Tasa de nacimiento ajustada por capacidad de carga
    a_birth <- max(0, lambda * X * (1 - X / K))
    
    # Tasa de muerte lineal
    a_death <- mu * X
    
    # Tasa total
    a_total <- a_birth + a_death
    
    if (a_total <= 0) break
    
    # Tiempo hasta el próximo evento
    t <- t + rexp(1, rate = a_total)
    
    # Determinar si ocurre nacimiento o muerte
    if (runif(1) < a_birth / a_total) {
      X <- X + 1  # nacimiento
    } else {
      X <- X - 1  # muerte
    }
    
    times <- c(times, t)
    pops <- c(pops, X)
    iter <- iter + 1
  }
  
  return(data.frame(t = times, X = pops))
}

# Ejemplo de simulación
set.seed(123)
sim <- logistic_growth_lambda_mu(lambda = 2.0, mu = 1.0, K = 50, X0 = 100, T_max = 50)

# Gráfico
plot(sim$t, sim$X, type = "s", xlab = "Tiempo", ylab = "Población",
     main = "Crecimiento Logístico Estocástico (λ = 2.0, μ = 1.0, K = 50)",
     col = "darkgreen", lwd = 2)
